console.log(
  'DeepShield content script loaded'
)

chrome.runtime.onMessage.addListener(
  (message) => {

    if (message.type === 'DETECTION_RESULT') {

      console.log(
        'DeepShield result:',
        message.result
      )

    }

  }
)