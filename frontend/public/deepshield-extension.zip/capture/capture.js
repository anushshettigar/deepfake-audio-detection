let captureStream = null
let audioContext = null
let mediaRecorder = null
let currentSessionId = null
let targetTabId = null

const DEFAULT_BACKEND_URL = "https://api.deepshield.app"
const CHUNK_DURATION = 3000

async function getBackendUrl() {
  try {
    const result = await chrome.storage.local.get(["backend_url"]);
    return result.backend_url || DEFAULT_BACKEND_URL;
  } catch {
    return DEFAULT_BACKEND_URL;
  }
}

async function setBackendUrl(url) {
  try {
    await chrome.storage.local.set({ backend_url: url });
    return true;
  } catch {
    return false;
  }
}

let recorderChunks = []
let chunkTimer = null
let stopping = false
let processingChunk = false

chrome.runtime.onMessage.addListener(
async (message, sender, sendResponse) => {


console.log(
  "DeepShield capture message:",
  message
)

if (message.type === "CAPTURE_START") {

  try {

    targetTabId =
      message.targetTabId || null

    const sessionId =
      await startCapture()

    sendResponse({
      status: "started",
      session_id: sessionId
    })

  } catch (error) {

    console.error(
      "DeepShield capture start error:",
      error
    )

    await stopCapture()

    sendResponse({
      status: "error",
      message:
        error?.message ||
        "Audio capture failed."
    })
  }

  return true
}


if (message.type === "CAPTURE_STOP") {

  try {

    await stopCapture()

    sendResponse({
      status: "stopped"
    })

  } catch (error) {

    console.error(
      "DeepShield capture stop error:",
      error
    )

    sendResponse({
      status: "error",
      message:
        error?.message ||
        "Unable to stop capture."
    })
  }

  return true
}

}
)

// ============================================================
// MIME TYPE
// ============================================================

function getMimeType() {

const types = [
"audio/webm;codecs=opus",
"audio/webm"
]

return types.find(
type =>
MediaRecorder.isTypeSupported(type)
)
}

// ============================================================
// START CAPTURE
// ============================================================

async function startCapture() {

if (mediaRecorder) {
return currentSessionId
}

if (!targetTabId) {


throw new Error(
  "No target browser tab was provided."
)


}

stopping = false
processingChunk = false
recorderChunks = []

// ==========================================================
// CREATE BACKEND SESSION
// ==========================================================

console.log(
"DeepShield: creating live session"
)

const sessionResponse =
await fetch(
`${await getBackendUrl()}/api/live-session/start`,
{
method: "POST"
}
)

if (!sessionResponse.ok) {

throw new Error(
  "Unable to create live detection session."
)


}

const sessionData =
await sessionResponse.json()

currentSessionId =
sessionData.session_id

console.log(
"DeepShield session:",
currentSessionId
)

// ==========================================================
// GET TAB AUDIO STREAM ID
// ==========================================================

console.log(
"DeepShield: requesting tab audio stream:",
targetTabId
)

const streamId =
await chrome.tabCapture.getMediaStreamId({
targetTabId
})

if (!streamId) {


throw new Error(
  "Unable to obtain the browser tab audio stream."
)


}

// ==========================================================
// CREATE TAB AUDIO STREAM
// ==========================================================

if (
!navigator.mediaDevices ||
!navigator.mediaDevices.getUserMedia
) {

throw new Error(
  "Audio capture is not available in this extension."
)


}

captureStream =
await navigator.mediaDevices.getUserMedia({

  audio: {

    mandatory: {

      chromeMediaSource:
        "tab",

      chromeMediaSourceId:
        streamId

    }

  },

  video: false
})


if (!captureStream) {


throw new Error(
  "Unable to create the tab audio stream."
)


}

console.log(
"DeepShield: tab audio captured"
)

// ==========================================================
// AUDIO CONTEXT
// ==========================================================

audioContext =
new AudioContext()

const source =
audioContext.createMediaStreamSource(
captureStream
)

const destination =
audioContext.createMediaStreamDestination()

source.connect(
destination
)

// ==========================================================
// START FIRST RECORDER
// ==========================================================

await startRecorder(
destination.stream
)

console.log(
"DeepShield: live recording started"
)

return currentSessionId
}

// ============================================================
// START ONE 3-SECOND RECORDING
// ============================================================

async function startRecorder(
stream
) {

if (stopping) {
return
}

const mimeType =
getMimeType()

if (!mimeType) {


throw new Error(
  "No compatible audio recording format is supported."
)


}

console.log(
"DeepShield audio format:",
mimeType
)

recorderChunks = []

mediaRecorder =
new MediaRecorder(
stream,
{
mimeType
}
)

mediaRecorder.onstart =
() => {


  console.log(
    "DeepShield: MediaRecorder started"
  )

  console.log(
    "DeepShield: recording standalone 3-second WebM"
  )
}


// ==========================================================
// COLLECT ALL DATA FOR THIS RECORDING
// ==========================================================

mediaRecorder.ondataavailable =
event => {


  if (
    event.data &&
    event.data.size > 0
  ) {

    recorderChunks.push(
      event.data
    )

    console.log(
      "DeepShield recorder data:",
      event.data.size,
      "bytes"
    )
  }
}

// ==========================================================
// WHEN RECORDING STOPS
// CREATE ONE COMPLETE WEBM
// ==========================================================

mediaRecorder.onstop =
async () => {

  console.log(
    "DeepShield: MediaRecorder stopped"
  )

  if (stopping) {

    recorderChunks = []
    mediaRecorder = null

    return
  }

  const chunks =
    recorderChunks

  recorderChunks = []
  mediaRecorder = null


  if (!chunks.length) {

    console.warn(
      "DeepShield: no audio data collected"
    )

    await restartRecorder()

    return
  }


  const mimeType =
    getMimeType() ||
    "audio/webm"


  const completeBlob =
    new Blob(
      chunks,
      {
        type: mimeType
      }
    )


  console.log(
    "======================================"
  )

  console.log(
    "DeepShield COMPLETE WEBM"
  )

  console.log(
    "Chunks:",
    chunks.length
  )

  console.log(
    "Complete size:",
    completeBlob.size,
    "bytes"
  )

  console.log(
    "======================================"
  )


  if (
    completeBlob.size < 1000
  ) {

    console.warn(
      "DeepShield: recording is too small, skipping"
    )

    await restartRecorder()

    return
  }


  processingChunk = true


  try {

    await sendAudioChunk(
      completeBlob
    )

  } catch (error) {

    console.error(
      "DeepShield chunk processing error:",
      error
    )

  } finally {

    processingChunk = false
  }


  await restartRecorder()
}

// ==========================================================
// RECORDER ERROR
// ==========================================================

mediaRecorder.onerror =
event => {


  console.error(
    "DeepShield recorder error:",
    event.error
  )

  chrome.runtime.sendMessage({

    type:
      "DETECTION_ERROR",

    message:
      event.error?.message ||
      "Audio recorder encountered an error."

  })
}

// ==========================================================
// START WITHOUT TIMESLICE
// ==========================================================

mediaRecorder.start()

console.log(
"DeepShield: recorder started"
)

// ==========================================================
// STOP AFTER 3 SECONDS
// ==========================================================

if (chunkTimer) {


clearTimeout(
  chunkTimer
)


}

chunkTimer =
setTimeout(
() => {

    if (
      mediaRecorder &&
      mediaRecorder.state !== "inactive"
    ) {

      console.log(
        "DeepShield: 3 seconds reached, stopping recorder"
      )

      mediaRecorder.stop()
    }

  },
  CHUNK_DURATION
)

}

// ============================================================
// RESTART RECORDER
// ============================================================

async function restartRecorder() {

if (stopping) {
return
}

if (!captureStream) {
return
}

if (!audioContext) {
return
}

const destinationStream =
audioContext.createMediaStreamDestination()

const source =
audioContext.createMediaStreamSource(
captureStream
)

source.connect(
destinationStream
)

await startRecorder(
destinationStream.stream
)
}

// ============================================================
// SEND COMPLETE AUDIO CHUNK
// ============================================================

async function sendAudioChunk(
audioBlob
) {

if (!currentSessionId) {

console.error(
  "DeepShield: no active session."
)

return

}

try {

const formData =
  new FormData()


formData.append(
  "file",
  audioBlob,
  `live-${Date.now()}.webm`
)


formData.append(
  "session_id",
  currentSessionId
)


console.log(
  "DeepShield: uploading COMPLETE WebM"
)

console.log(
  "Session:",
  currentSessionId
)

console.log(
  "Chunk size:",
  audioBlob.size,
  "bytes"
)


const response =
  await fetch(
    `${await getBackendUrl()}/api/live-analyze`,
    {
      method: "POST",
      body: formData
    }
  )


const responseText =
  await response.text()


if (!response.ok) {

  throw new Error(
    responseText ||
    "Live audio analysis failed."
  )
}


let data

try {

  data =
    JSON.parse(
      responseText
    )

} catch {

  throw new Error(
    "Backend returned an invalid JSON response."
  )
}


console.log(
  "======================================"
)

console.log(
  "DEEPSHIELD LIVE ANALYSIS"
)

console.log(
  "Label:",
  data.label
)

console.log(
  "Confidence:",
  data.confidence
)

console.log(
  "Class ID:",
  data.class_id
)

console.log(
  "Session:",
  data.session_id
)

console.log(
  "Chunk:",
  data.chunk
)

console.log(
  "======================================"
)


chrome.runtime.sendMessage({

  type:
    "DETECTION_RESULT",

  data: {

    status:
      data.status ||
      "audio_received",

    state:
      data.state ||
      "COMPLETED",

    label:
      data.label ||
      null,

    confidence:
      data.confidence ??
      null,

    class_id:
      data.class_id ??
      null,

    session_id:
      data.session_id ||
      currentSessionId,

    chunk:
      data.chunk ??
      null,

    message:
      data.message ||
      "Live audio chunk analyzed successfully."

  }

})


} catch (error) {


console.error(
  "DeepShield backend error:",
  error
)


chrome.runtime.sendMessage({

  type:
    "DETECTION_ERROR",

  message:
    error?.message ||
    "Unable to analyze live audio."

})

}
}

// ============================================================
// STOP CAPTURE
// ============================================================

async function stopCapture() {

stopping = true

if (chunkTimer) {


clearTimeout(
  chunkTimer
)

chunkTimer = null

}

const sessionId =
currentSessionId

console.log(
"DeepShield: stopping capture"
)

// ==========================================================
// STOP RECORDER
// ==========================================================

if (mediaRecorder) {


try {

  if (
    mediaRecorder.state !==
    "inactive"
  ) {

    mediaRecorder.stop()
  }

} catch (error) {

  console.warn(
    "DeepShield recorder stop error:",
    error
  )
}

mediaRecorder =
  null

}

recorderChunks = []

// ==========================================================
// STOP STREAM
// ==========================================================

if (captureStream) {


captureStream
  .getTracks()
  .forEach(
    track => {

      try {

        track.stop()

      } catch (error) {

        console.warn(
          "DeepShield track stop error:",
          error
        )
      }
    }
  )

captureStream =
  null


}

// ==========================================================
// CLOSE AUDIO CONTEXT
// ==========================================================

if (audioContext) {


try {

  await audioContext.close()

} catch (error) {

  console.warn(
    "DeepShield audio context close error:",
    error
  )
}

audioContext =
  null

}

// ==========================================================
// CLOSE BACKEND SESSION
// ==========================================================

if (sessionId) {

try {

  const response =
    await fetch(
      `${await getBackendUrl()}/api/live-session/stop?session_id=${encodeURIComponent(
        sessionId
      )}`,
      {
        method: "POST"
      }
    )


  if (response.ok) {

    const data =
      await response.json()

    console.log(
      "DeepShield session stopped:",
      data
    )

  } else {

    console.warn(
      "DeepShield session stop returned:",
      response.status
    )
  }

} catch (error) {

  console.error(
    "DeepShield session close error:",
    error
  )
}

}

currentSessionId =
null

targetTabId =
null

processingChunk =
false

console.log(
"DeepShield: capture stopped"
)
}
