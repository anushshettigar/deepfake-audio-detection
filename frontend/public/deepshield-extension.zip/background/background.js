let captureTabId = null
let capturePageTabId = null

const DEFAULT_STATE = {
  detecting: false,
  status: "Ready",
  statusText: "Start detection to monitor call audio",
  result: "—",
  confidence: "Waiting for audio",
  engineStatus: "READY",
  chunksReceived: 0,
  lastAnalysis: null,
  sessionId: null
}


chrome.runtime.onInstalled.addListener(
  async () => {

    await chrome.storage.local.set(
      DEFAULT_STATE
    )

  }
)


chrome.runtime.onStartup.addListener(
  async () => {

    const existing =
      await chrome.storage.local.get(
        Object.keys(DEFAULT_STATE)
      )

    if (
      existing.detecting === undefined
    ) {

      await chrome.storage.local.set(
        DEFAULT_STATE
      )

    }

  }
)


chrome.runtime.onMessage.addListener(
  async (
    message,
    sender,
    sendResponse
  ) => {

    console.log(
      "DeepShield background message:",
      message
    )


    if (
      message.type ===
      "START_DETECTION"
    ) {

      try {

        const tabs =
          await chrome.tabs.query({
            active: true,
            currentWindow: true
          })


        if (
          !tabs ||
          tabs.length === 0
        ) {

          throw new Error(
            "No active browser tab found."
          )

        }


        const tab =
          tabs[0]


        captureTabId =
          tab.id


        const captureUrl =
          chrome.runtime.getURL(
            "capture/capture.html"
          )


        const captureTab =
          await chrome.tabs.create({
            url: captureUrl,
            active: false
          })


        capturePageTabId =
          captureTab.id


        await waitForTabLoad(
          captureTab.id
        )


        const response =
          await chrome.tabs.sendMessage(
            captureTab.id,
            {
              type: "CAPTURE_START",
              targetTabId: captureTabId
            }
          )


        if (
          response?.status !==
          "started"
        ) {

          throw new Error(
            response?.message ||
            "Audio capture failed."
          )

        }


        await chrome.storage.local.set({

          detecting: true,

          status:
            "Listening...",

          statusText:
            "Call audio is being analyzed",

          result:
            "CAPTURING",

          confidence:
            "Waiting for analysis",

          engineStatus:
            "ACTIVE",

          chunksReceived:
            0,

          lastAnalysis:
            null,

          sessionId:
            response.session_id ||
            null

        })


        sendResponse({
          status: "started"
        })

      } catch (error) {

        console.error(
          "DeepShield start error:",
          error
        )


        await chrome.storage.local.set({

          detecting: false,

          status:
            "Capture Error",

          statusText:
            error.message,

          result:
            "ERROR",

          confidence:
            "Unable to analyze audio",

          engineStatus:
            "ERROR"

        })


        sendResponse({

          status: "error",

          message:
            error.message

        })

      }

      return true

    }


    if (
      message.type ===
      "DETECTION_RESULT"
    ) {

      try {

        const data =
          message.data || {}


        const current =
          await chrome.storage.local.get([
            "chunksReceived"
          ])


        const chunks =
          (
            current.chunksReceived ||
            0
          ) + 1


        const label =
          data.label ||
          data.state ||
          data.status ||
          "PENDING"


        const confidenceValue =
          data.confidence


        const confidenceText =
          confidenceValue !==
            undefined &&
          confidenceValue !==
            null

            ? `${confidenceValue}% confidence`

            : `Audio chunks analyzed: ${chunks}`


        await chrome.storage.local.set({

          detecting: true,

          status:
            "Listening...",

          statusText:
            "Call audio is being analyzed",

          result:
            String(label).toUpperCase(),

          confidence:
            confidenceText,

          engineStatus:
            "PROCESSING",

          chunksReceived:
            chunks,

          lastAnalysis:
            data,

          sessionId:
            data.session_id ||
            null

        })


        console.log(
          "DeepShield stored detection result:",
          data
        )


        sendResponse({
          status: "stored"
        })

      } catch (error) {

        console.error(
          "Failed to store detection result:",
          error
        )


        sendResponse({

          status: "error",

          message:
            error.message

        })

      }

      return true

    }


    if (
      message.type ===
      "DETECTION_ERROR"
    ) {

      console.error(
        "DeepShield detection error:",
        message.message
      )


      await chrome.storage.local.set({

        status:
          "Capture Error",

        statusText:
          message.message ||
          "Backend analysis failed.",

        result:
          "ERROR",

        confidence:
          "Unable to analyze audio",

        engineStatus:
          "ERROR"

      })


      sendResponse({
        status: "stored"
      })


      return true

    }


    if (
      message.type ===
      "STOP_DETECTION"
    ) {

      try {

        if (
          capturePageTabId !== null
        ) {

          try {

            await chrome.tabs.sendMessage(
              capturePageTabId,
              {
                type:
                  "CAPTURE_STOP"
              }
            )

          } catch (error) {

            console.warn(
              "Could not stop capture page:",
              error
            )

          }


          try {

            await chrome.tabs.remove(
              capturePageTabId
            )

          } catch (error) {

            console.warn(
              "Could not close capture page:",
              error
            )

          }

        }


        capturePageTabId =
          null

        captureTabId =
          null


        await chrome.storage.local.set({

          detecting: false,

          status:
            "Stopped",

          statusText:
            "Detection stopped",

          engineStatus:
            "READY"

        })


        sendResponse({
          status: "stopped"
        })

      } catch (error) {

        console.error(
          "DeepShield stop error:",
          error
        )


        sendResponse({

          status: "error",

          message:
            error.message

        })

      }

      return true

    }

  }
)


function waitForTabLoad(
  tabId
) {

  return new Promise(
    resolve => {

      chrome.tabs.get(
        tabId,
        tab => {

          if (
            chrome.runtime.lastError
          ) {

            resolve()

            return

          }


          if (
            tab.status ===
            "complete"
          ) {

            resolve()

            return

          }


          const listener =
            (
              updatedTabId,
              changeInfo
            ) => {

              if (
                updatedTabId ===
                  tabId &&
                changeInfo.status ===
                  "complete"
              ) {

                chrome.tabs.onUpdated
                  .removeListener(
                    listener
                  )

                resolve()

              }

            }


          chrome.tabs.onUpdated
            .addListener(
              listener
            )

        }
      )

    }
  )

}